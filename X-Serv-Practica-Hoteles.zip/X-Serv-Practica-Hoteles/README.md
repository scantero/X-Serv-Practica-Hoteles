# X-Serv-Practica-Hoteles
Repositorio para la práctica final de SARO/SAT. Curso 2015-2016

    Nombre y titulación: Sandra Cantero Rabanillo, Ingeniería de Tecnologías de Telecomunicaciones.

    Nombre de su cuenta en el laboratorio del alumno: sdkr

    Nombre de usuario en GitHub: santero

    Resumen de las peculiaridades de parte obligatoria:
        Acceso a la web de esmadrid.org desde la página principal y una breve explicación

    Lista de funcionalidades opcionales:
		  Uso de favicon.
      Canal RSS de la página principal.
      Pestaña para acceder a la página del usuario cuando está registrado desde cualquier parte.
      Búsqueda de alojamientos más cercanos por código postal


	URL de vídeos:
		 Parte obligatoria: https://youtu.be/hqUho7CBlBA
		 Parte optativa: https://youtu.be/JrXGl3KbkvY
